#' Sample dataset for examples. Derived from CDC 122 cities dataset.
#' 
#' The dataset is a simple year-week dataset of influenza deaths.  
#' 
#' @format A data frame with 2847 rows and 4 variables:
#' \describe{
#'   \item{year}{observation year, integer}
#'   \item{week}{observation week, integer}
#'   \item{fludeaths}{No. of deaths attributed to Pneumonia / Influenza}
#'   \item{alldeaths}{No. of deaths due to any cause}
#'   \item{perc_fludeaths}{fludeaths / alldeaths * 100}
#'   \item{yrweek_dt}{year-week-day of rate, Date}
#'   \item{fluyr}{Influenza season, Starts from June until May of next year} 
#'   \item{prop_flupos}{No. of influenza positive isolates / total no. tested, from NREVSS data, see ?nrevss, the data was linked with the cdc122 data with a 2 week lead to account for delays in reporting}
#'   \item{week_in_order}{A ordered count of weeks from beginning to end of dataset}
#'   \item{epi}{A logical vector indicating epidemic seasons}
#' }
#' @source \url{https://data.cdc.gov/dataset/Deaths-in-122-U-S-cities-1962-2016-122-Cities-Mort/mr8w-325u}
"fludta"