#' CDC WHO NREVSS Laboratory Data
#' 
#' Description from CDC Flu Portal Dashboard:
#' Virologic Surveillance — Approximately 110 U.S. World Health Organization (WHO)
#' Collaborating Laboratories and 270 National Respiratory and Enteric Virus 
#' Surveillance System (NREVSS) laboratories, which include both public health 
#' and clinical laboratories, located throughout the United States participate 
#' in virologic surveillance for influenza. All public health and clinical 
#' laboratories report the total number of respiratory specimens tested 
#' and the number positive for influenza each week to CDC, along with age 
#' or age group of the person, if available. Beginning in the 2015-16 season, 
#' reports from public health and clinical laboratories were presented separately 
#' in the weekly influenza update, FluView. Data from clinical laboratories 
#' include the weekly total number of specimens tested, the number of positive 
#' influenza tests, and the percent positive by influenza type. 
#' Data presented from public health laboratories include the weekly 
#' total number of specimens tested, the number of positive influenza tests, 
#' and the number by influenza virus type, influenza A subtype, and 
#' influenza B lineage. In addition, the age group distribution of 
#' influenza positive tests are also summarized in Fluview. A subset of 
#' the influenza viruses collected by public health laboratories are sent to 
#' CDC for further characterization, including antiviral resistance 
#' testing and antigenic and/or genetic characterization, and this 
#' information is presented in the antiviral resistance and 
#' virus characterization sections of the FluView report. 
#' 
#' Some variables renamed from original file for parsimony.
#' 
#' @format A data frame with 14094 rows and 12 variables:
#' \describe{
#'   \item{state}{Proper name for U.S. State, character string}
#'   \item{year}{observation year, integer}
#'   \item{week}{observation week, integer}
#'   \item{spec_tot}{Total specimens tested}
#'   \item{spec_pos}{Total specimens positive for Influenza}
#'   \item{type_A_}{Each column represents specimens positive for that type/subtype}
#'   ...
#' }
#' @source \url{https://gis.cdc.gov/grasp/fluview/fluportaldashboard.html}
"nrevss"