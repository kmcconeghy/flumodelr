library(testthat)
library(flumodelr)

test_check("flumodelr")
