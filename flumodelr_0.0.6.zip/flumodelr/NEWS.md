# Version 0.0.7 08-08-2018  

  * added additional unit tests  
  * fixed errors in 05- vignette  
  * modified fluglm to accept negative binomial option  
  * modified viral option to accept multiple viral types  

# Version 0.0.6 01-12-2018  

  * fixed author typo 
  * added viral option to fluglm
  * renamed serflm to fluserf
  
# Version 0.0.5 01-11-2018  

  * Streamlined tidy eval between functions
  * converted lm to glm functions
  * added flum wrapper function
  * renamed and edited fluexcess to fludiff
  * added fluglm function

# Version 0.0.4 12-19-2017  

  * fluplot.R function written
  * ird function added

# Version 0.0.3 12-07-2017  

  * serflm.R function written

# Version 0.0.2 10-26-2017  

  * GitPages / Vignettes Set-up

# Version 0.0.1

Project set-up, data upload.


